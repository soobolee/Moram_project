package moram.clas.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import moram.clas.service.ClasServiceImpl;
import moram.clas.service.IClasService;
import moram.vo.ZipVO;


@WebServlet("/ZipSearch.do")
public class ZipSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		// 0. 클라이언트 요청시 전송데이타 받기 - id
		String dong = request.getParameter("dong");

		// 1. service객체 얻기
		IClasService service = ClasServiceImpl.getInstance();

		// 2. service메소드 호출 - 결과값 받기
		List<ZipVO> list = service.selectByDong(dong);

		// 결과값을 이용해서 json데이터 생성하거나 출력한다
		// jsp응답페이지로 forward시켜서 위임한다

		// 3. 결과값을 request에 저장
		request.setAttribute("res", list);

		// 4. jsp로 forward
		request.getRequestDispatcher("class/zipcode.jsp").forward(request, response);
	}

}
