package moram.management.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 시설 장소의 이용시간을 수정하는 클래스
 */
@WebServlet("/PlaceTimeUpdate.do")
public class PlaceTimeUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public PlaceTimeUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		
	}

}
