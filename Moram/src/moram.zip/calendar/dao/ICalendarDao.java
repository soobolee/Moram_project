package moram.calendar.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import moram.vo.Calendar2VO;


public interface ICalendarDao {
	public ArrayList<Calendar2VO> calenList(String place_no) throws SQLException;
}
