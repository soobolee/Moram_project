package moram.mypage.service;

import java.util.List;
import java.util.Map;

import moram.vo.ClassVO;
import moram.vo.MemberVO;
import moram.vo.MoramVO;
import moram.vo.PlaceVO;
import moram.vo.SubscribeVO;
import moram.vo.TeacherVO;

public interface IMypageService {

	
	public MemberVO memberInfo(String memId);
	
	public int memberInfoUpdate(MemberVO vo);
	
	public int youJigi(String memId);   // 밑에꺼랑 같이 사용하려고 만든 메서드
	
	public String moramSubscribePay(SubscribeVO vo);
	
	public int passwordChk(String memPass);
	
	public List<PlaceVO> placeTimeRezList(String memId);
	
	public String placeTimeRezrePay(String PLNO);
	
	public List<ClassVO> preferClassList(String memId);
	
	public List<MoramVO> preferMoramList(String memId);
	
	public Object teacherApply(TeacherVO vo);
	
	public int memberDelete(String memId);
	
	public int moramWeim(Map<String, String> morami);

	public int placepayrefund(String payNo);
	
	public List<MoramVO> mainMoram();
	
	public List<ClassVO> mainClass();
	
	public int passUpdate(Map<String, String> memPass);
	
	public int moramFive(String memId);
	
	public int moramHun(String memId);
	
}
