package moram.vo;

public class SubscribeVO {
	
	private String subscribe_payno;
	private int subscribe_no;
	private String mem_id;
	private String subscribe_pdate;
	private String subscribe_edate;
	private String subscribe_paytype;
	private String subscribe_pstate;
	private String subscribe_name;
	
	public String getSubscribe_name() {
		return subscribe_name;
	}
	public void setSubscribe_name(String subscribe_name) {
		this.subscribe_name = subscribe_name;
	}
	public String getSubscribe_payno() {
		return subscribe_payno;
	}
	public void setSubscribe_payno(String subscribe_payno) {
		this.subscribe_payno = subscribe_payno;
	}
	public int getSubscribe_no() {
		return subscribe_no;
	}
	public void setSubscribe_no(int subscribe_no) {
		this.subscribe_no = subscribe_no;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getSubscribe_pdate() {
		return subscribe_pdate;
	}
	public void setSubscribe_pdate(String subscribe_pdate) {
		this.subscribe_pdate = subscribe_pdate;
	}
	public String getSubscribe_edate() {
		return subscribe_edate;
	}
	public void setSubscribe_edate(String subscribe_edate) {
		this.subscribe_edate = subscribe_edate;
	}
	public String getSubscribe_paytype() {
		return subscribe_paytype;
	}
	public void setSubscribe_paytype(String subscribe_paytype) {
		this.subscribe_paytype = subscribe_paytype;
	}
	public String getSubscribe_pstate() {
		return subscribe_pstate;
	}
	public void setSubscribe_pstate(String subscribe_pstate) {
		this.subscribe_pstate = subscribe_pstate;
	}
	

}
