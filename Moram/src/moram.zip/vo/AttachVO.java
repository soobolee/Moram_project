package moram.vo;

public class AttachVO {
	
	private int board_no;
	private String attach_no;
	private String attach_path;
	private String attach_name;
	private String attact_type;
	
	public int getBoard_no() {
		return board_no;
	}
	public void setBoard_no(int board_no) {
		this.board_no = board_no;
	}
	public String getAttach_no() {
		return attach_no;
	}
	public void setAttach_no(String attach_no) {
		this.attach_no = attach_no;
	}
	public String getAttach_path() {
		return attach_path;
	}
	public void setAttach_path(String attach_path) {
		this.attach_path = attach_path;
	}
	public String getAttach_name() {
		return attach_name;
	}
	public void setAttach_name(String attach_name) {
		this.attach_name = attach_name;
	}
	public String getAttact_type() {
		return attact_type;
	}
	public void setAttact_type(String attact_type) {
		this.attact_type = attact_type;
	}
	
	
}
