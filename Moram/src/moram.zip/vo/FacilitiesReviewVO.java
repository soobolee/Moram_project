package moram.vo;

public class FacilitiesReviewVO {
	private int fareview_no;
	private String facilities_no;
	private String fareview_cont;
	private String fareview_wdate;
	private String fareview_writer;
	private String fareview_image;
	public int getFareview_no() {
		return fareview_no;
	}
	public void setFareview_no(int fareview_no) {
		this.fareview_no = fareview_no;
	}
	public String getFacilities_no() {
		return facilities_no;
	}
	public void setFacilities_no(String facilities_no) {
		this.facilities_no = facilities_no;
	}
	public String getFareview_cont() {
		return fareview_cont;
	}
	public void setFareview_cont(String fareview_cont) {
		this.fareview_cont = fareview_cont;
	}
	public String getFareview_wdate() {
		return fareview_wdate;
	}
	public void setFareview_wdate(String fareview_wdate) {
		this.fareview_wdate = fareview_wdate;
	}
	public String getFareview_writer() {
		return fareview_writer;
	}
	public void setFareview_writer(String fareview_writer) {
		this.fareview_writer = fareview_writer;
	}
	public String getFareview_image() {
		return fareview_image;
	}
	public void setFareview_image(String fareview_image) {
		this.fareview_image = fareview_image;
	}
	
	
}