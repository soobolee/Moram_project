package moram.vo;

public class VoteVO {
	private int board_no;
	private int vote_no;
	private String vote_cont;
	
	public int getBoard_no() {
		return board_no;
	}
	public void setBoard_no(int board_no) {
		this.board_no = board_no;
	}
	public int getVote_no() {
		return vote_no;
	}
	public void setVote_no(int vote_no) {
		this.vote_no = vote_no;
	}
	public String getVote_cont() {
		return vote_cont;
	}
	public void setVote_cont(String vote_cont) {
		this.vote_cont = vote_cont;
	}
	
	
}
