package moram.vo;

public class ClassReplyVO {
	
	
	private String classcmt_wdate;
	private String class_no;
	private int classcmt_no;
	private String classcmt_cont;
	private String classcmt_writer;
	private String mem_id;
	private String mem_div;
	
	public synchronized String getMem_div() {
		return mem_div;
	}
	public synchronized void setMem_div(String mem_div) {
		this.mem_div = mem_div;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getClasscmt_wdate() {
		return classcmt_wdate;
	}
	public void setClasscmt_wdate(String classcmt_wdate) {
		this.classcmt_wdate = classcmt_wdate;
	}
	public String getClass_no() {
		return class_no;
	}
	public void setClass_no(String class_no) {
		this.class_no = class_no;
	}
	public int getClasscmt_no() {
		return classcmt_no;
	}
	public void setClasscmt_no(int classcmt_no) {
		this.classcmt_no = classcmt_no;
	}
	public String getClasscmt_cont() {
		return classcmt_cont;
	}
	public void setClasscmt_cont(String classcmt_cont) {
		this.classcmt_cont = classcmt_cont;
	}
	public String getClasscmt_writer() {
		return classcmt_writer;
	}
	public void setClasscmt_writer(String classcmt_writer) {
		this.classcmt_writer = classcmt_writer;
	}

	
}
