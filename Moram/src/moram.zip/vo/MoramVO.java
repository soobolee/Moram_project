package moram.vo;

public class MoramVO {
	private String mr_no;
	private String mr_name;
	private String moramjigi;
	private String mr_info;
	private String mr_image;
	private String mr_cdate;
	private int mr_limit;
	private String mr_rgn;
	private int subscribe_no;
	private int subject_no;
	private String mr_state;
	public String getMr_no() {
		return mr_no;
	}
	public void setMr_no(String mr_no) {
		this.mr_no = mr_no;
	}
	public String getMr_name() {
		return mr_name;
	}
	public void setMr_name(String mr_name) {
		this.mr_name = mr_name;
	}
	public String getMoramjigi() {
		return moramjigi;
	}
	public void setMoramjigi(String moramjigi) {
		this.moramjigi = moramjigi;
	}
	public String getMr_info() {
		return mr_info;
	}
	public void setMr_info(String mr_info) {
		this.mr_info = mr_info;
	}
	public String getMr_image() {
		return mr_image;
	}
	public void setMr_image(String mr_image) {
		this.mr_image = mr_image;
	}
	public String getMr_cdate() {
		return mr_cdate;
	}
	public void setMr_cdate(String mr_cdate) {
		this.mr_cdate = mr_cdate;
	}
	public int getMr_limit() {
		return mr_limit;
	}
	public void setMr_limit(int mr_limit) {
		this.mr_limit = mr_limit;
	}
	public String getMr_rgn() {
		return mr_rgn;
	}
	public void setMr_rgn(String mr_rgn) {
		this.mr_rgn = mr_rgn;
	}
	public int getSubscribe_no() {
		return subscribe_no;
	}
	public void setSubscribe_no(int subscribe_no) {
		this.subscribe_no = subscribe_no;
	}
	public int getSubject_no() {
		return subject_no;
	}
	public void setSubject_no(int subject_no) {
		this.subject_no = subject_no;
	}
	public String getMr_state() {
		return mr_state;
	}
	public void setMr_state(String mr_state) {
		this.mr_state = mr_state;
	}
	
	
	
}
