package moram.vo;

public class FacilitiesVO {
	
	private String facilities_no;
	private String facilities_name;
	private String facilities_rgn;
	private String facilities_info;
	private String facilities_addr;
	private String facilities_jdate;
	private String facilities_jstate;
	private int subject_no;
	private String place_no;
	private String place_name;
	private String place_price;
	private String placetime_state;
		
	
	public String getPlacetime_state() {
		return placetime_state;
	}
	public void setPlacetime_state(String placetime_state) {
		this.placetime_state = placetime_state;
	}
	public String getPlace_no() {
		return place_no;
	}
	public void setPlace_no(String place_no) {
		this.place_no = place_no;
	}
	public String getPlace_name() {
		return place_name;
	}
	public void setPlace_name(String place_name) {
		this.place_name = place_name;
	}
	public String getPlace_price() {
		return place_price;
	}
	public void setPlace_price(String place_price) {
		this.place_price = place_price;
	}
	public String getFacilities_no() {
		return facilities_no;
	}
	public void setFacilities_no(String facilities_no) {
		this.facilities_no = facilities_no;
	}
	public String getFacilities_name() {
		return facilities_name;
	}
	public void setFacilities_name(String facilities_name) {
		this.facilities_name = facilities_name;
	}
	public String getFacilites_rgn() {
		return facilities_rgn;
	}
	public void setFacilites_rgn(String facilites_rgn) {
		this.facilities_rgn = facilites_rgn;
	}
	public String getFacilites_info() {
		return facilities_info;
	}
	public void setFacilites_info(String facilites_info) {
		this.facilities_info = facilites_info;
	}
	public String getFacilites_addr() {
		return facilities_addr;
	}
	public void setFacilites_addr(String facilites_addr) {
		this.facilities_addr = facilites_addr;
	}
	public String getFacilites_jdate() {
		return facilities_jdate;
	}
	public void setFacilites_jdate(String facilites_jdate) {
		this.facilities_jdate = facilites_jdate;
	}
	public String getFacilites_jstate() {
		return facilities_jstate;
	}
	public void setFacilites_jstate(String facilites_jstate) {
		this.facilities_jstate = facilites_jstate;
	}
	public int getSubject_no() {
		return subject_no;
	}
	public void setSubject_no(int subject_no) {
		this.subject_no = subject_no;
	}

}
