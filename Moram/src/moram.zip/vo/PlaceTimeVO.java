package moram.vo;

public class PlaceTimeVO {
	private String placetime_no;
	private String place_no;
	private String placetime_date;
	private String placetime_stime;
	private String placetime_etime;
	private String placetime_state;
	private int placetime_price;
	public String getPlacetime_no() {
		return placetime_no;
	}
	public void setPlacetime_no(String placetime_no) {
		this.placetime_no = placetime_no;
	}
	public String getPlace_no() {
		return place_no;
	}
	public void setPlace_no(String place_no) {
		this.place_no = place_no;
	}
	public String getPlacetime_date() {
		return placetime_date;
	}
	public void setPlacetime_date(String placetime_date) {
		this.placetime_date = placetime_date;
	}
	public String getPlacetime_stime() {
		return placetime_stime;
	}
	public void setPlacetime_stime(String placetime_stime) {
		this.placetime_stime = placetime_stime;
	}
	public String getPlacetime_etime() {
		return placetime_etime;
	}
	public void setPlacetime_etime(String placetime_etime) {
		this.placetime_etime = placetime_etime;
	}
	public String getPlacetime_state() {
		return placetime_state;
	}
	public void setPlacetime_state(String placetime_state) {
		this.placetime_state = placetime_state;
	}
	public int getPlacetime_price() {
		return placetime_price;
	}
	public void setPlacetime_price(int placetime_price) {
		this.placetime_price = placetime_price;
	}
	
	
	
}
