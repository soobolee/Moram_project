package moram.vo;

public class PlaceVO {

	
	private String placepay_no;
	private String placetime_no;
	private String mem_id;
	private String placepay_date;
	private int placepay_price;
	private String placepay_state;
	private String facilities_no;
	private String place_no;
	private String place_name;
	private String place_info;
	private String placerepay_no;
	private String placerepay_rdate;
	private String placerepay_cdate;
	private String placerepay_state;
	private String placetime_date;
	private String placetime_stime;
	private String placetime_etime;
	private int placetime_price;
	private int place_price;
	
	public String getPlacepay_no() {
		return placepay_no;
	}
	public void setPlacepay_no(String placepay_no) {
		this.placepay_no = placepay_no;
	}
	public String getPlacetime_no() {
		return placetime_no;
	}
	public void setPlacetime_no(String placetime_no) {
		this.placetime_no = placetime_no;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getPlacepay_date() {
		return placepay_date;
	}
	public void setPlacepay_date(String placepay_date) {
		this.placepay_date = placepay_date;
	}
	public int getPlacepay_price() {
		return placepay_price;
	}
	public void setPlacepay_price(int placepay_price) {
		this.placepay_price = placepay_price;
	}
	public String getPlacepay_state() {
		return placepay_state;
	}
	public void setPlacepay_state(String placepay_state) {
		this.placepay_state = placepay_state;
	}
	public String getFacilities_no() {
		return facilities_no;
	}
	public void setFacilities_no(String facilities_no) {
		this.facilities_no = facilities_no;
	}
	public String getPlace_no() {
		return place_no;
	}
	public void setPlace_no(String place_no) {
		this.place_no = place_no;
	}
	public String getPlace_name() {
		return place_name;
	}
	public void setPlace_name(String place_name) {
		this.place_name = place_name;
	}
	public String getPlace_info() {
		return place_info;
	}
	public void setPlace_info(String place_info) {
		this.place_info = place_info;
	}
	public String getPlacerepay_no() {
		return placerepay_no;
	}
	public void setPlacerepay_no(String placerepay_no) {
		this.placerepay_no = placerepay_no;
	}
	public String getPlacerepay_rdate() {
		return placerepay_rdate;
	}
	public void setPlacerepay_rdate(String placerepay_rdate) {
		this.placerepay_rdate = placerepay_rdate;
	}
	public String getPlacerepay_cdate() {
		return placerepay_cdate;
	}
	public void setPlacerepay_cdate(String placerepay_cdate) {
		this.placerepay_cdate = placerepay_cdate;
	}
	public String getPlacerepay_state() {
		return placerepay_state;
	}
	public void setPlacerepay_state(String placerepay_state) {
		this.placerepay_state = placerepay_state;
	}
	public String getPlacetime_date() {
		return placetime_date;
	}
	public void setPlacetime_date(String placetime_date) {
		this.placetime_date = placetime_date;
	}
	public String getPlacetime_stime() {
		return placetime_stime;
	}
	public void setPlacetime_stime(String placetime_stime) {
		this.placetime_stime = placetime_stime;
	}
	public String getPlacetime_etime() {
		return placetime_etime;
	}
	public void setPlacetime_etime(String placetime_etime) {
		this.placetime_etime = placetime_etime;
	}
	public int getPlacetime_price() {
		return placetime_price;
	}
	public void setPlacetime_price(int placetime_price) {
		this.placetime_price = placetime_price;
	}
	public int getPlace_price() {
		return place_price;
	}
	public void setPlace_price(int place_price) {
		this.place_price = place_price;
	}
	
	
	
	
	
	
}
