package moram.vo;

public class MoramMemberVO {
	private String mem_id  ;
	private String mr_no   ;
	private String mr_info ;
	
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getMr_no() {
		return mr_no;
	}
	public void setMr_no(String mr_no) {
		this.mr_no = mr_no;
	}
	public String getMr_info() {
		return mr_info;
	}
	public void setMr_info(String mr_info) {
		this.mr_info = mr_info;
	}
	
	
}
