package moram.vo;

public class TeacherVO {

	
	private String mem_id;
	private String teacher_plan;
	private String teacher_wdate;
	
	
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getTeacher_plan() {
		return teacher_plan;
	}
	public void setTeacher_plan(String teacher_plan) {
		this.teacher_plan = teacher_plan;
	}
	public String getTeacher_wdate() {
		return teacher_wdate;
	}
	public void setTeacher_wdate(String teacher_wdate) {
		this.teacher_wdate = teacher_wdate;
	}

	
}
