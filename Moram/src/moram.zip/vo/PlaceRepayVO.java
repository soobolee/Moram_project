package moram.vo;

public class PlaceRepayVO {
	private String placepay_no;
	private String placetime_no;
	private String mem_id;
	private String placepay_date;
	private int placepay_price;
	private String placepay_state;
	
	public String getPlacepay_no() {
		return placepay_no;
	}
	public void setPlacepay_no(String placepay_no) {
		this.placepay_no = placepay_no;
	}
	public String getPlacetime_no() {
		return placetime_no;
	}
	public void setPlacetime_no(String placetime_no) {
		this.placetime_no = placetime_no;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getPlacepay_date() {
		return placepay_date;
	}
	public void setPlacepay_date(String placepay_date) {
		this.placepay_date = placepay_date;
	}
	public int getPlacepay_price() {
		return placepay_price;
	}
	public void setPlacepay_price(int placepay_price) {
		this.placepay_price = placepay_price;
	}
	public String getPlacepay_state() {
		return placepay_state;
	}
	public void setPlacepay_state(String placepay_state) {
		this.placepay_state = placepay_state;
	}
}
