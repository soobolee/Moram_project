package moram.vo;

public class ReplyVO {

	private int board_no;
	private int reply_no;
	private String reply_writer;
	private String reply_cont;
	private String reply_wdate;
	private String reply_udate;
	private String mem_id;
	
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public int getBoard_no() {
		return board_no;
	}
	public void setBoard_no(int board_no) {
		this.board_no = board_no;
	}
	public int getReply_no() {
		return reply_no;
	}
	public void setReply_no(int reply_no) {
		this.reply_no = reply_no;
	}
	public String getReply_writer() {
		return reply_writer;
	}
	public void setReply_writer(String reply_writer) {
		this.reply_writer = reply_writer;
	}
	public String getReply_cont() {
		return reply_cont;
	}
	public void setReply_cont(String reply_cont) {
		this.reply_cont = reply_cont;
	}
	public String getReply_wdate() {
		return reply_wdate;
	}
	public void setReply_wdate(String reply_wdate) {
		this.reply_wdate = reply_wdate;
	}
	public String getReply_udate() {
		return reply_udate;
	}
	public void setReply_udate(String reply_udate) {
		this.reply_udate = reply_udate;
	}
	

}
