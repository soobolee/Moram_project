package moram.vo;

public class BoardLikeVO {
	
	private int board_no;
	private int boardlike_no;
	private String mem_id;
	
	public int getBoard_no() {
		return board_no;
	}
	public void setBoard_no(int board_no) {
		this.board_no = board_no;
	}
	public int getBoardlike_no() {
		return boardlike_no;
	}
	public void setBoardlike_no(int boardlike_no) {
		this.boardlike_no = boardlike_no;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	
	
	
}
