package moram.vo;

public class ClassVO {

	private String class_no     ;
	private String class_name   ;
	private String mem_id       ;
	private String class_image  ;
	private String class_info   ;
	private String class_addr   ;
	private String class_rgn    ;
	private String subcat_no    ;
	private int subject_no;
	private String subject_name;
	private int class_acs;
	
	
	
	public int getClass_acs() {
		return class_acs;
	}
	public void setClass_acs(int class_acs) {
		this.class_acs = class_acs;
	}
	public int getSubject_no() {
		return subject_no;
	}
	public void setSubject_no(int subject_no) {
		this.subject_no = subject_no;
	}
	public String getSubject_name() {
		return subject_name;
	}
	public void setSubject_name(String subject_name) {
		this.subject_name = subject_name;
	}
	public String getClass_no() {
		return class_no;
	}
	public void setClass_no(String class_no) {
		this.class_no = class_no;
	}
	public String getClass_name() {
		return class_name;
	}
	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getClass_image() {
		return class_image;
	}
	public void setClass_image(String class_image) {
		this.class_image = class_image;
	}
	public String getClass_info() {
		return class_info;
	}
	public void setClass_info(String class_info) {
		this.class_info = class_info;
	}
	public String getClass_addr() {
		return class_addr;
	}
	public void setClass_addr(String class_addr) {
		this.class_addr = class_addr;
	}
	public String getClass_rgn() {
		return class_rgn;
	}
	public void setClass_rgn(String class_rgn) {
		this.class_rgn = class_rgn;
	}
	public String getSubcat_no() {
		return subcat_no;
	}
	public void setSubcat_no(String subcat_no) {
		this.subcat_no = subcat_no;
	}
	
	
}                               
