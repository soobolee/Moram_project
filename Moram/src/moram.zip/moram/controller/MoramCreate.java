package moram.moram.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import moram.moram.service.IMoramService;
import moram.moram.service.MoramServiceImpl;
import moram.vo.MoramVO;

@WebServlet("/MoramCreate.do")
public class MoramCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 request.setCharacterEncoding("UTF-8");
	 response.setCharacterEncoding("UTF-8");
	 response.setContentType("text/html charset=utf-8");
	 
	 PrintWriter out = response.getWriter();
	 
	 
	 MoramVO vo = new MoramVO();
	 try {
		BeanUtils.populate(vo, request.getParameterMap());
	 	} catch (IllegalAccessException | InvocationTargetException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	 	}
	 
	 	out.print(vo.getMr_name());
	 
	 
	 //service객체 만들기
	 IMoramService service = MoramServiceImpl.getInstance();
	 
	 //메서드
	 String result = service.insertMoram(vo);
	 
	 request.setAttribute("res", result);
	
	 request.getRequestDispatcher("result/resultStr.jsp").forward(request, response);
	 
	/* out.print("{");

		if(result==null){
		
			out.print("\"sw\" : \"실패\"");
		
		}else{
			out.print("\"sw\": \"성공\"");
		}
			out.print("}");
	 */
			
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
